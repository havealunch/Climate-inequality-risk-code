"""Baseline replication scripts for the climate-inequality manuscript.

All estimates are calculated from the supplied inputs. No manuscript coefficient
or p-value is hard-coded in this file.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf


def fit_clustered(formula: str, data: pd.DataFrame, cluster: str) -> pd.DataFrame:
    model = smf.ols(formula, data=data).fit(
        cov_type="cluster", cov_kwds={"groups": data[cluster], "use_correction": True}
    )
    ci = model.conf_int()
    return pd.DataFrame(
        {
            "term": model.params.index,
            "estimate": model.params.values,
            "clustered_se": model.bse.values,
            "p_value": model.pvalues.values,
            "ci_low": ci.iloc[:, 0].values,
            "ci_high": ci.iloc[:, 1].values,
            "n_observations": int(model.nobs),
            "n_clusters": int(data[cluster].nunique()),
        }
    )


def run_global(path: Path, output: Path) -> None:
    d = pd.read_csv(path).dropna()
    formula = (
        "gini_change_annualized ~ loss_gdp_winsor + gdp_pc_growth + urbanization + "
        "trade_openness + control_corruption + education_expenditure + C(country) + C(year)"
    )
    fit_clustered(formula, d, "country").to_csv(output / "global_twfe_coefficients.csv", index=False)


def run_china(path: Path, output: Path) -> None:
    d = pd.read_csv(path).dropna()
    d["exposure_post"] = d["exposure_z"] * d["post2020"]
    formula = "ln_urban_rural_ratio ~ exposure_post + C(city) + C(year)"
    baseline = fit_clustered(formula, d, "city")
    d["log_covid_burden"] = np.log1p(d["covid_cases_per_100k"])
    covid = fit_clustered(formula + " + log_covid_burden", d, "city")
    pd.concat([baseline.assign(specification="baseline"), covid.assign(specification="covid_adjusted")]).to_csv(
        output / "china_city_twfe_coefficients.csv", index=False
    )


def run_household(path: Path, output: Path) -> None:
    d = pd.read_csv(path).dropna()
    d["education_medical_balance"] = d["ln_education_pc"] - d["ln_medical_pc"]
    d["exposure_post"] = d["exposure_z"] * d["post2020"]
    formula = "education_medical_balance ~ exposure_post + C(household_id) + C(year)"
    fit_clustered(formula, d, "city" if "city" in d.columns else "household_id").to_csv(
        output / "household_balance_coefficients.csv", index=False
    )


def run_policy(path: Path, output: Path) -> None:
    d = pd.read_csv(path).dropna()
    wide = d.pivot(index="household_id", columns="year", values=["income_pc", "education_pc"])
    if not {2020, 2022}.issubset(set(wide.columns.get_level_values(1))):
        raise ValueError("cfps_policy_panel.csv must contain both 2020 and 2022 observations.")
    out = pd.DataFrame(index=wide.index)
    out["income_2020"] = wide[("income_pc", 2020)]
    out["education_2020"] = wide[("education_pc", 2020)]
    out["education_2022"] = wide[("education_pc", 2022)]
    out["shortfall"] = (out["education_2020"] - out["education_2022"]).clip(lower=0)
    out["income_quintile"] = pd.qcut(out["income_2020"], 5, labels=False, duplicates="drop") + 1
    budget = 0.15 * out["shortfall"].sum()
    low = out["income_quintile"] == 1
    universal = budget / len(out)
    equal_targeted = budget / low.sum()
    proportional = np.where(low & (out["shortfall"].sum() > 0), budget * out["shortfall"] / out.loc[low, "shortfall"].sum(), 0)
    summary = pd.DataFrame(
        {
            "rule": ["universal_equal", "lowest_quintile_equal", "lowest_quintile_shortfall_proportional"],
            "common_budget": [budget, budget, budget],
            "lowest_quintile_shortfall_coverage": [
                min(universal * low.sum() / out.loc[low, "shortfall"].sum(), 1),
                min(equal_targeted * low.sum() / out.loc[low, "shortfall"].sum(), 1),
                min(np.asarray(proportional)[low.to_numpy()].sum() / out.loc[low, "shortfall"].sum(), 1),
            ],
        }
    )
    summary.to_csv(output / "policy_allocation_summary.csv", index=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("analysis", choices=["global", "china", "household", "policy"])
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    {"global": run_global, "china": run_china, "household": run_household, "policy": run_policy}[args.analysis](args.input, args.output)


if __name__ == "__main__":
    main()
